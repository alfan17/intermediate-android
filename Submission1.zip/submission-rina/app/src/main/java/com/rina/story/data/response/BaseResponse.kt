package com.rina.story.data.response

import com.google.gson.annotations.SerializedName

open class BaseResponse {
    @SerializedName("error")
    var error: Boolean = false

    @SerializedName("message")
    var message: String = "Success"
}