package com.rina.story.data.repository

import com.rina.story.data.response.BaseResponse
import com.rina.story.data.response.LoginResponse
import com.rina.story.data.services.UserServices

class UserRepository(private val service: UserServices) {

    suspend fun login(email: String, password: String): LoginResponse {
        return service.login(email, password)
    }

    suspend fun register(name:String, email: String, password: String): BaseResponse {
        return service.register(name, email, password)
    }
}