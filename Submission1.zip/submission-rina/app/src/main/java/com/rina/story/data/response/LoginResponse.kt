package com.rina.story.data.response

import com.google.gson.annotations.SerializedName

class LoginResponse(
    @SerializedName("loginResult")
    val result: Result? = null,
): BaseResponse() {
    data class Result (
        @SerializedName("userId")
        val userId: String,

        @SerializedName("name")
        val name: String,

        @SerializedName("token")
        val token: String
    )
}