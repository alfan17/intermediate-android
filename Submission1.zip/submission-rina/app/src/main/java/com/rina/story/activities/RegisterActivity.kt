package com.rina.story.activities

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.rina.story.R
import com.rina.story.databinding.ActivityRegisterBinding
import com.rina.story.viewmodels.RegisterState
import com.rina.story.viewmodels.UserViewModel
import org.koin.android.ext.android.inject

class RegisterActivity : AppCompatActivity() {

    private lateinit var registerBinding: ActivityRegisterBinding

    private val viewmodel: UserViewModel by inject()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        registerBinding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(registerBinding.root)

        registerBinding.outlinePassword.accept {
            registerBinding.register.isEnabled = it
        }

        registerBinding.login.setOnClickListener {
            finish()
        }

        registerBinding.register.setOnClickListener {
            viewmodel.register(
                registerBinding.name.text.toString(),
                registerBinding.email.text.toString(),
                registerBinding.outlinePassword.gettext().toString()).observe(this@RegisterActivity) { observer ->
                    when(observer) {
                        RegisterState.Loading -> {
                            registerBinding.containerProgressbar.root.visibility = View.VISIBLE
                        }
                        RegisterState.ErrorEmail -> {
                            registerBinding.outlineEmail.error = getString(R.string.message_error_email_format)
                        }
                        RegisterState.ErrorFullname -> {
                            registerBinding.outlineName.error = resources.getString(R.string.message_error_nama_format)
                        }
                        RegisterState.Success -> {
                            MaterialAlertDialogBuilder(this, R.style.ThemeOverlay_MaterialComponents_Dialog_Alert)
                                .setTitle(resources.getString(R.string.lebel_informasi))
                                .setMessage(getString(R.string.message_success_register))
                                .setCancelable(false)
                                .setPositiveButton(resources.getString(R.string.label_dialog_positive_action)) { dialog, _ ->
                                    dialog.dismiss()
                                    finish()
                                }.show()
                        }
                        is RegisterState.Error -> {
                            registerBinding.containerProgressbar.root.visibility = View.GONE

                            MaterialAlertDialogBuilder(this, R.style.ThemeOverlay_MaterialComponents_Dialog_Alert)
                                .setTitle(resources.getString(R.string.lebel_informasi))
                                .setMessage(observer.message)
                                .setCancelable(true)
                                .setPositiveButton(resources.getString(R.string.label_dialog_positive_action)) { dialog, _ ->
                                    dialog.dismiss()
                                }.show()
                        }
                    }
            }
        }
    }
}