package com.rina.story.activities

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.provider.Settings
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityOptionsCompat
import androidx.core.util.Pair
import androidx.lifecycle.lifecycleScope
import androidx.paging.LoadState
import androidx.recyclerview.widget.GridLayoutManager
import com.rina.story.R
import com.rina.story.adapters.ItemAdapter
import com.rina.story.data.response.LoginResponse
import com.rina.story.databinding.ActivityMainBinding
import com.rina.story.library.PreferencesExt.delete
import com.rina.story.library.PreferencesExt.getObject
import com.rina.story.viewmodels.StoryViewModel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import org.koin.android.ext.android.inject

class MainActivity : AppCompatActivity() {

    private val sharedPreferences: SharedPreferences by inject()

    private val viewmodel: StoryViewModel by inject()

    private lateinit var mainBinding: ActivityMainBinding

    private lateinit var itemAdapter: ItemAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mainBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(mainBinding.root)

        if (sharedPreferences.getObject<LoginResponse.Result>("loginuser") == null) {
            startActivity(Intent(this@MainActivity, LoginActivity::class.java))
            finishAffinity()
        }

        itemAdapter = ItemAdapter { bind, item ->
            val intent = Intent(this, DetailActivity::class.java)

            intent.putExtra("item;", item)

            startActivity(intent, ActivityOptionsCompat.makeSceneTransitionAnimation(this,
                Pair(bind.banner, "banner_detail"),
                Pair(bind.banner, "name_detail")
            ).toBundle())
        }

        mainBinding.recyclerview.layoutManager = GridLayoutManager(this@MainActivity, 2)
        mainBinding.recyclerview.adapter = itemAdapter

        viewmodel.getList().observe(this@MainActivity) {
            itemAdapter.submitData(lifecycle, it)
        }

        lifecycleScope.launch {
            itemAdapter.loadStateFlow.collect { stateAdaper ->
                when(stateAdaper.append) {
                    LoadState.Loading -> {
                        mainBinding.progressBar.visibility = View.VISIBLE
                    }
                    is LoadState.NotLoading -> {
                        mainBinding.progressBar.visibility = View.INVISIBLE
                    }
                    is LoadState.Error -> {
                        mainBinding.progressBar.visibility = View.INVISIBLE
                        Toast.makeText(this@MainActivity, (stateAdaper.append as LoadState.Error).error.localizedMessage, Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        itemAdapter.refresh()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.actionadd -> {
                startActivity(Intent(this@MainActivity, CreateActivity::class.java))
            }
            R.id.actionlanguage -> {
                startActivity(Intent(Settings.ACTION_LOCALE_SETTINGS))
            }
            R.id.actionlogout -> {
                sharedPreferences.delete("loginuser")
                startActivity(Intent(this@MainActivity, LoginActivity::class.java))
                finishAffinity()
            }
        }
        return true
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.menu_main, menu)
        return true
    }
}