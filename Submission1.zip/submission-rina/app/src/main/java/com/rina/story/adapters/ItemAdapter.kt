package com.rina.story.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.rina.story.R
import com.rina.story.data.response.StoriesResponse
import com.rina.story.databinding.RecyclerviewItemBinding

class ItemAdapter(private var onClickListener: (RecyclerviewItemBinding, StoriesResponse.Story) -> Unit): PagingDataAdapter<StoriesResponse.Story, ItemAdapter.ViewHolder>(diffUtils) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(RecyclerviewItemBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        getItem(position)?.let { item ->
            holder.bindItem(item)
            holder.binding.root.setOnClickListener {
                onClickListener.invoke(holder.binding, item)
            }
        }
    }

    class ViewHolder(val binding: RecyclerviewItemBinding): RecyclerView.ViewHolder(binding.root) {
        fun bindItem(item: StoriesResponse.Story) {
            binding.nama.text = item.name
            binding.desc.text = item.description
            binding.created.text = binding.root.resources.getString(R.string.label_tanggal, item.createdAt)

            Glide.with(itemView.context)
                .load(item.photoUrl)
                .centerCrop()
                .into(binding.banner)
        }
    }

    companion object {
        private val diffUtils = object : DiffUtil.ItemCallback<StoriesResponse.Story>() {
            override fun areItemsTheSame(
                oldItem: StoriesResponse.Story,
                newItem: StoriesResponse.Story
            ): Boolean = oldItem.id == newItem.id

            override fun areContentsTheSame(
                oldItem: StoriesResponse.Story,
                newItem: StoriesResponse.Story
            ): Boolean = oldItem.id == newItem.id
        }
    }
}