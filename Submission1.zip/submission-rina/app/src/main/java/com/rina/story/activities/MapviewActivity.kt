package com.rina.story.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.rina.story.R

class MapviewActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mapview)
    }
}