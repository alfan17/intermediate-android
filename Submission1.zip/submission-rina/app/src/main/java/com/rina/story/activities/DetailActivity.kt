package com.rina.story.activities

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.rina.story.R
import com.rina.story.data.response.StoriesResponse
import com.rina.story.databinding.ActivityDetailBinding

import android.view.MenuItem




class DetailActivity : AppCompatActivity() {

    private lateinit var detailBinding: ActivityDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        detailBinding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(detailBinding.root)

        val item = intent.getParcelableExtra<StoriesResponse.Story>("item;")

        if (item != null) {
            detailBinding.nama.text = item.name
            detailBinding.desc.text = item.description
            detailBinding.created.text = getString(R.string.label_tanggal, item.createdAt)

            supportActionBar?.setDisplayHomeAsUpEnabled(true)
            supportActionBar?.title = item.name

            Glide.with(applicationContext)
                .load(item.photoUrl)
                .centerCrop()
                .into(detailBinding.banner)

        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}