package com.rina.story.customview

import android.content.Context
import android.graphics.Canvas
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.text.method.PasswordTransformationMethod
import android.util.AttributeSet
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.rina.story.R

class PasswordEdittext: TextInputLayout {

    private lateinit var editText: TextInputEditText

    private var acceptListener: ((Boolean) -> Unit)? = null

    constructor(context: Context) : super(context) {
        init()
    }

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        init()
    }

    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        init()
    }

    private fun init() {
        editText = TextInputEditText(context)
        editText.inputType = InputType.TYPE_TEXT_VARIATION_PASSWORD
        editText.transformationMethod = PasswordTransformationMethod.getInstance()
        editText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {

            }

            override fun afterTextChanged(s: Editable) {
                error = if (s.length < 6) {
                    resources.getString(R.string.message_error_typing_password)
                } else {
                    ""
                }

                isErrorEnabled = !error.isNullOrBlank()
                acceptListener?.invoke(error.isNullOrBlank())
            }
        })

        createEditBox(editText)
    }

    fun accept(acceptListener: (Boolean) -> Unit) {
        this.acceptListener = acceptListener
    }

    fun gettext() = editText.text

    override fun onDraw(canvas: Canvas?) {
        super.onDraw(canvas)

        hint = resources.getString(R.string.label_password)

    }

    private fun createEditBox(editText: TextInputEditText) {
        val layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
        editText.setPadding(32, 42, 32, 42)
        editText.layoutParams = layoutParams
        addView(editText)
    }

}